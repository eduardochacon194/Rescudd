
package DoubleLinkedList;

import java.util.Iterator;

import node.node;

public class doubleLinkedlist<T>{
	private node<T> start=null, end=null;
	protected T[] array;
	
	public doubleLinkedlist() {
		start =new node<T>();
		start.setIndex(-1);//la lista inicia en 0
		end =new node<T>();
		end.setIndex(-1);
	}
	public doubleLinkedlist(T value) {
		this();//incia el otro constructor
		end.getBack().setIndex(0);
		//end.setBack(new node<T>(value));
		start.setNext(end.getBack());
		start.getNext().setIndex(0);
	}
	/*
	 * 
	 */
	public boolean remove(T value) 
	{
		node	<T> tmp=search(value);
		if(tmp!=null)
		{
			if(tmp.getNext()!=null)
			{
				tmp.getNext().setBack(tmp.getBack());
			}else
			{
				end.setBack(tmp.getBack());
			}
			if(tmp.getBack()!=null) {
				tmp.getBack().setNext(tmp.getNext());
			}else
			{
				start.setNext(tmp.getNext());
			}
			return true;	
		}
				return false;
	}
	/*
	Agregar un nodo al inicio de la lista  
	*/
	public void addStart(T value) {
		node<T> tmp = start.getNext();
		node<T> nuevo = new node<T>(value);
		nuevo.setNext(tmp);
		start.setNext(new node<T>(value));
		if(tmp==null){
			end.setBack(start.getNext());
			start.getNext().setIndex(0);
		}else {
			start.getNext().setNext(tmp);
			tmp.setBack(start.getNext());
		}
	}
	/*
	Agregar al final
	*/
	public void addEnd(T value) {
		node<T> tmp = end.getBack();
		node<T> nuevo = new node<T>(value);
		nuevo.setBack(tmp);
		end.setBack(new node<T>(value));
		if(tmp==null){
			start.setNext(end.getBack());
			end.getBack().setIndex(0);
		}else {
			end.getBack().setBack(tmp);
			tmp.setNext(end.getBack());
		}
	}
	/*
	 Buscar un nodo en una direccion
	 */
	public node<T> search(T value)
	{
		return search(value,start, end);
	}
	public node<T> search(T value, node<T> start, node<T> end)
	{
		if (start.getNext()==null|| end.getBack()==null) return null;
		else if(start.getNext().getValue().equals(value))return start.getNext(); 
		else if(end.getBack().getValue().equals(value))return end.getBack();
		else if(start.getNext().equals(end) || start.equals(end) ) return null;
		return search(value, start.getNext(), end.getBack());
	}
	/*
	 Buscar un nodo en dos direcciones
	 */
	public void sorch()
	{
		
	}
	/*
	Imprimir  
	*/
	public void printer() {
		printer(start);
	}
	public void printerInicio() {
		node<T> tmp = start;
		while (tmp.getNext()!=null) {
			tmp = tmp.getNext();
			System.out.println(tmp.getValue());
		}
		System.gc();
	}
	public void printerfinal() {
		node<T> tmp = end;
		while (tmp.getBack()!=null) {
			tmp = tmp.getBack();
			System.out.println(tmp.getValue());
		}
		System.gc();
	}
	private void printer(node<T> tmp) {
		if (tmp.getNext()== null)
			return;
		else{
			System.out.println(tmp.getNext().getValue());
		    printer(tmp.getNext());
		}
		System.gc();
	}
	public boolean isEmpy()
	{
		if (start.getNext()==null && end.getBack()==null)
		{
			return true;
		}
		else
		{
			return false;
		}
		
		
	}
	public node<T> indexof(T value)
	{
		reindex();
		return indexof(value,start);
	}
	public node<T> indexof(T value, node<T> lista)
	{
		reindex();
		if (lista.getNext()==null)return null;
		if(lista.getNext().getValue().equals(value))return lista.getNext(); 
		return indexof(value, lista.getNext());
	}
	private void reindex() {
		int aux=1;
		node<T> tmp = start;
		while (tmp.getNext()!=null) {
			tmp = tmp.getNext();
			tmp.setIndex(aux);
			aux++;
		}
		System.gc();
	}
	public void pronterIndex() {
		reindex();
		node<T> tmp = start;
		while (tmp.getNext()!=null) {
			tmp = tmp.getNext();
			System.out.println(tmp.getIndex());
		}
		System.gc();
	}
	public void getLast()
	{
		node<T> tmp = end;
		if(end.getBack()!=null)
			System.out.println(tmp.getBack().getValue());
	}
	public void RemoveBefore(T value)
	{
		node<T> tmp=search(value);
		if(!isEmpy() && tmp!=null)
		{
			if(tmp.getBack().getBack()!=null) {
				tmp.setBack(tmp.getBack().getBack());
				if(start.getNext().getNext()==tmp)
				{
					start.setNext(start.getNext().getNext());
				}else
				{
					tmp=tmp.getBack();
					tmp.setNext(tmp.getNext().getNext());
				}
			}else 
			{
				tmp.setBack(null);
				start.setNext(start.getNext().getNext());
			}
		}
	}
	public void RemoveAfter(T value)
	{
		node<T> tmp=search(value);
		if(!isEmpy() && tmp!=null)
		{
			if(tmp.getNext().getNext()!=null) {
				tmp.setNext(tmp.getNext().getNext());
				if(end.getBack().getBack()==tmp)
				{
					end.setBack(end.getBack().getBack());
				}else
				{
					tmp=tmp.getNext();
					tmp.setBack(tmp.getBack().getBack());
				}
			}else 
			{
				tmp.setNext(null);
				end.setBack(end.getBack().getBack());
			}
		}
	}
	public int tama()
	{
		int tama = 0;
		while(start.getNext() != null){
		     start = start.getNext();
		     tama++;     
		   }
		return tama;
	}
	public void remplazar(T value, T remp)
	{
		search(value).setValue(remp);
	}
        public void clear()
	{
        start.setNext(null);
        end.setBack(null);
        System.gc();
	}
        public void getFirst()
	{
		node<T> tmp = start.getNext();
		System.out.println(tmp.getValue());
	}
        public void RemoveLast() 
        { 
            end.setBack(end.getBack().getBack());
            end.getBack().setNext(null);  
	}
        public void RemoveFirst()
	{
            start.setNext(start.getNext().getNext());
            start.getNext().setBack(null);
	}
///--------------------------------------------------------------------------
    	public String ExisteElemento(T value)
    	{
    		return ExisteElemento(start,value);
    	}
    	
    	private String ExisteElemento(node<T> no,T value)
    	{
    		if(no!=null)
    		{
    			if(no.getNext().getValue().equals(value))
    			{
    				return "SI EXISTE";
    			}
    			else
    			{
    				return ExisteElemento(no.getNext(),value);
    			}
    				
    		}
    		return "";
    		
    	}
///----------------------------------------------------------------------------------
    	public int Ocurrencia(T value)
    	{
    		return Ocurrencia(start,value);
    	}
    	
    	private int Ocurrencia(node<T> L,T value)
    	{
    		start.getNext();
    		int cont = 0;
    		if(L!=null)
    		{
    			if(value.equals(L.getValue()))
    			{
    				cont++;
    				return cont + Ocurrencia(L.getNext(),value);
    				
    			}
    			else
    			{
    				return Ocurrencia(L.getNext(),value);
    			}
    			
    		}
    		return cont;
    	}
///---------------------------------------------------------------------------
    	public String Suma()
    	{
    		return Suma(start.getNext());
    	}
    	
    	private String Suma(node<T> L)
    	{
    		if(L!=null)
    		{
    			if(L.getValue()!=null)
    			{
    				int su = (int) L.getValue();
    				int s = (su + su);
    				return Suma(L.getBack()) + s ;
    			
    			}
    		}
    		
    		return "";
    	}
///------------------------------------------------------------------------------
    	
}