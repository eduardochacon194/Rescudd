package App;

import DoubleLinkedList.doubleLinkedlist;
import node.node;

public class app {

	public static <T> void main(String[] args) 
	{
		doubleLinkedlist<String> name = new doubleLinkedlist<>();
		doubleLinkedlist<String> nam = new doubleLinkedlist<>();
		doubleLinkedlist<Integer> na = new doubleLinkedlist<>();
		name.addStart("Ana");
		name.addStart("Perla");
		name.addStart("Tania");
		name.addStart("Ana");
		na.addStart(15);
		na.addStart(15);
		//name.SonIguales(name,nam);
		System.out.println(name.ExisteElemento("Ana"));
		System.out.println("VECES QUE SE REPITE " + name.Ocurrencia("Ana"));
		System.out.println("SUMA DE LOS NODOS " + na.Suma());
	}
}